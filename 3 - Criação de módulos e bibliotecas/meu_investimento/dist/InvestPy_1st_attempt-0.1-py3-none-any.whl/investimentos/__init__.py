# -*- coding: utf-8 -*-
"""
Created on Sun Apr  6 14:32:50 2025

@author: josea
"""

from .investimentos import calcular_retorno_investimento
from .investimentos import calcular_juros_compostos 
from .investimentos import converter_taxa_anual_para_mensal 
from .investimentos import alcular_cagr



